# descuento_producto/models/__init__.py
from . import descuento_producto