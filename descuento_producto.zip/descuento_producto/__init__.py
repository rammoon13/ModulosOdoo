# descuento_productos/__init__.py
from . import models